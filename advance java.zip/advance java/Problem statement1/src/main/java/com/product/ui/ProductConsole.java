package com.product.ui;

public class ProductConsole {

}
