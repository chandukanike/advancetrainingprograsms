package com.product.entity;

public class Product {

}
